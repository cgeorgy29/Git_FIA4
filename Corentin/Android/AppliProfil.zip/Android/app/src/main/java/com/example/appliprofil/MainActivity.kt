package com.example.appliprofil

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.Button
//import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MailOutline
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.windowsizeclass.ExperimentalMaterial3WindowSizeClassApi
import androidx.compose.material3.windowsizeclass.WindowSizeClass
import androidx.compose.material3.windowsizeclass.WindowWidthSizeClass
import androidx.compose.material3.windowsizeclass.calculateWindowSizeClass
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
//import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.appliprofil.ui.theme.AppliProfilTheme
import java.util.*

var back : Color = Color.White
class MainActivity : ComponentActivity() {
    @OptIn(ExperimentalMaterial3WindowSizeClassApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
                val windowSizeClass = calculateWindowSizeClass(this)
                // A surface container using the 'background' color from the theme
                Surface(modifier = Modifier.fillMaxSize(), color = back) {
                    Screen(windowSizeClass)
            }
        }
    }

    override fun isUiContext(): Boolean {
        return super.isUiContext()
    }
}
@Composable
fun Screen(classe : WindowSizeClass) {
    val classHauteur = classe.heightSizeClass
    val classLargeur = classe.widthSizeClass
    when (classLargeur) {
        WindowWidthSizeClass.Compact -> {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Image_ppd()
                Titre("Georgy Corentin")
                Texte("Elève en 4è année du cycle ingénieur")
                Texte("Ecole d'ingénieur ISIS - INU Champolion")
                Spacer(Modifier.height(50.dp))

                Row {
                    Image(imageVector = Icons.Filled.MailOutline, contentDescription = "mail")
                    Texte(carac = "georgy.crt@gmail.com")
                }
                Row {
                    Image(imageVector = Icons.Filled.Star, contentDescription = "mail")
                    Texte(carac = "www.linkedin.com/in/corentin-georgy")
                }
                Button(onClick = {}) {
                    Text(text = "Button")
                }
            }
        }
        else -> {
            Row ( verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceEvenly){
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Image_ppd()
                    Titre("Georgy Corentin")
                    Texte("Elève en 4è année du cycle ingénieur")
                    Texte("Ecole d'ingénieur ISIS - INU Champolion")
                }
                Column() {
                    Row {
                        Image(imageVector = Icons.Filled.MailOutline, contentDescription = "mail")
                        Texte(carac = "georgy.crt@gmail.com")
                    }
                    Row {
                        Image(imageVector = Icons.Filled.Star, contentDescription = "mail")
                        Texte(carac = "www.linkedin.com/in/corentin-georgy")
                    }
                    Spacer(Modifier.height(30.dp))
                    Button(onClick = {}) {
                        Text(text = "Button")
                    }
                }


            }
        }
    }
}

//fun randColor () : Color{
//    var rnd = Random()
//    back = Color(rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256))
//    return back
//}

@Composable
fun Image_ppd() {
    Image(painterResource(id = R.mipmap.yoruppd), contentDescription = "photo de profil",
        Modifier
            .clip(CircleShape)
            .size(200.dp)
        )
}

@Composable
fun Titre(carac : String){
    Text(text = carac, fontSize = 21.sp)
}
@Composable
fun Texte(carac : String){
    Text(text = carac, fontSize = 14.sp)
}
/*
@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    AppliProfilTheme {
        Screen(windowSizeClass)
    }
}*/
