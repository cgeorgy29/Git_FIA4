package diningphilosophers;

import java.io.IOException;

public class Table {
	public static void main(String[] args) {
		ChopStick s1 = new ChopStick();
		ChopStick s2 = new ChopStick();
		ChopStick s3 = new ChopStick();
		Philosopher rigaud = new Philosopher("Rigaud", s1, s2);
		Philosopher conchon  = new Philosopher("Conchon", s2, s3);
		Philosopher bastide = new Philosopher("Bastide", s3, s1);
		rigaud.start();
		conchon.start();
		bastide.start();
                // attendre la frappe d’une touche dans la console
		try {
			System.in.read();
		}
		catch (IOException ex) {
		}
		rigaud.arreteToi();
		conchon.arreteToi();
		bastide.arreteToi();
                
	}
}